// A1.js - Task 1: Library Book Management API
// Run: node file/A1.js
// Configure MONGO_URI in the project .env file.
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');

const app = express();
app.use(express.json());
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} ${req.method} ${req.originalUrl}`);
  next();
});

const bookSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  author: { type: String, required: true, trim: true },
  price: { type: Number, min: 1 },
  category: { type: String, trim: true },
  isAvailable: { type: Boolean, default: true }
}, { timestamps: true });
const Book = mongoose.model('Book', bookSchema);

app.post('/books', async (req, res, next) => {
  try {
    const book = await Book.create(req.body);
    res.status(201).json({ message: 'Book created successfully', book });
  } catch (err) {
    if (err.name === 'ValidationError' || err.name === 'CastError')
      return res.status(400).json({ message: err.message });
    next(err);
  }
});
app.get('/books', async (req, res, next) => {
  try { res.status(200).json(await Book.find()); } catch (err) { next(err); }
});
app.get('/books/:id', async (req, res, next) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    res.status(200).json(book);
  } catch (err) {
    if (err.name === 'CastError') return res.status(400).json({ message: 'Invalid book ID' });
    next(err);
  }
});
app.put('/books/:id', async (req, res, next) => {
  try {
    const book = await Book.findByIdAndUpdate(req.params.id, req.body,
      { new: true, runValidators: true });
    if (!book) return res.status(404).json({ message: 'Book not found' });
    res.status(200).json({ message: 'Book updated successfully', book });
  } catch (err) {
    if (err.name === 'ValidationError' || err.name === 'CastError')
      return res.status(400).json({ message: err.message });
    next(err);
  }
});
app.delete('/books/:id', async (req, res, next) => {
  try {
    const book = await Book.findByIdAndDelete(req.params.id);
    if (!book) return res.status(404).json({ message: 'Book not found' });
    res.status(200).json({ message: 'Book deleted successfully' });
  } catch (err) {
    if (err.name === 'CastError') return res.status(400).json({ message: 'Invalid book ID' });
    next(err);
  }
});
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: 'Internal server error' });
});

const PORT = process.env.PORT || 3000;
mongoose.connect(process.env.MONGO_URI)
  .then(() => app.listen(PORT, () => console.log(`A1 API running on port ${PORT}`)))
  .catch(err => { console.error('MongoDB connection failed:', err.message); process.exit(1); });
